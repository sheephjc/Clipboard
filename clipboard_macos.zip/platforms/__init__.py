"""Platform adapters for Clipboard."""

