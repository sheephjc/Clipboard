"""macOS platform adapter package."""

