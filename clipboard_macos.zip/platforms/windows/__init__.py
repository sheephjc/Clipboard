"""Windows platform adapter package."""

