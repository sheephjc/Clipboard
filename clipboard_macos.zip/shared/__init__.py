"""Shared Clipboard application primitives."""

